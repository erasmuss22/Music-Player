import java.util.ArrayList;
import java.util.Collections;

/**
 * Main song browser application.
 */
public class Browser {

    // TODO: add any private fields or methods you need

	/**
	 * Main song browser application. Build a library of available songs, then
	 * read a series of song browser selections and show the matching songs for
	 * each.
	 * 
	 * @param args
	 *            command-line arguments
	 */
	public static void main(final String[] args) {
	    // TODO: implement this method
	}

    private static void printInOrder(SimpleSet<Song> songs) {
        // Do not remove or modify this method!
        ArrayList<String> list = new ArrayList<String>();
        for (Song song : songs)
            list.add(song.toString());
        Collections.sort(list);
        for (String item : list)
            System.out.println(item);
    }

}