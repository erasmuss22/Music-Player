import java.util.Iterator;

/**
 * Concrete implementation of sets using doubly-linked lists.
 * <p>
 * <strong>Modify this class to implement the required {@link SimpleSet} methods
 * along with any private fields or methods you feel are
 * necessary.</strong>
 * 
 * @param <E>
 *            the type of data to be stored in this set
 **/

public class LinkedSet<E> implements SimpleSet<E> {

    // TODO: add any private fields or methods you need

    /**
     * Create a new, empty list.
     */
    public LinkedSet() {
        // TODO: implement this constructor
    }

    @Override
    public boolean add(E item) {
        // TODO: implement this method
        return false;
    }

    @Override
    public boolean contains(E target) {
        // TODO: implement this method
        return false;
    }

    @Override
    public boolean isEmpty() {
        // TODO: implement this method
        return false;
    }

    @Override
    public Iterator<E> iterator() {
        // TODO: implement this method
        return null;
    }

    @Override
    public int size() {
        // TODO: implement this method
        return 0;
    }

	@Override
	public boolean remove(E item) {
        // TODO: implement this method
        return false;
	}

	@Override
	public SimpleSet<E> union(SimpleSet<E> other) {
        // TODO: implement this method
        return null;
	}

	@Override
	public SimpleSet<E> intersection(SimpleSet<E> other) {
        // TODO: implement this method
        return null;
	}

	@Override
	public void clear() {
        // TODO: implement this method
	}
}
