import java.util.Iterator;

/**
 * Implementation of the {@link Iterator} interface for use with
 * {@link LinkedSet}.
 * <p>
 * <strong>Modify this class to implement the required {@link Iterator} methods
 * along with any constructors, fields, or other methods you feel are
 * necessary.</strong>
 * 
 * @author Ben Liblit
 * @param <E>
 *            the type of data stored in the list
 */
public class LinkedSetIterator<E> implements Iterator<E> {

    // TODO: add any constructors, private fields, or private methods you need

    @Override
    public boolean hasNext() {
        // TODO: implement this method
        return false;
    }

    public E next() {
        // TODO: implement this method
        return null;
    }

    public void remove() {
        // TODO: implement this method
        throw new UnsupportedOperationException();
    }
}
