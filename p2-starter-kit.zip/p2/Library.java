import java.io.File;
import java.io.IOException;

/**
 * Concrete implementation of a music library, consisting of a set of songs.
 * <p>
 * <strong>Modify this class to implement the required {@link LibraryInterface}
 * methods along with any private fields or methods you feel are
 * necessary.</strong>
 */
public class Library implements LibraryInterface {

    // TODO: add any private fields or methods you need

    /**
     * Create a new music library, reading song metadata from the given
     * filename.
     * 
     * @param filename
     *            name of the file containing song metadata
     * @throws IOException
     *             if the named file cannot be found or read
     */
    public Library(final File filename) throws IOException {
        // TODO: implement this constructor
    }

    @Override
    public SimpleSet<Song> songsHavingGenre(String genre) {
        // TODO: implement this method
        return null;
    }

    @Override
    public SimpleSet<Song> songsHavingArtist(String artist) {
        // TODO: implement this method
        return null;
    }

    @Override
    public SimpleSet<Song> songsHavingAlbum(String album) {
        // TODO: implement this method
        return null;
    }

    @Override
    public SimpleSet<Song> allSongs() {
        // TODO: implement this method
        return null;
    }

    @Override
    public SimpleSet<String> allGenres() {
        // TODO: implement this method
        return null;
    }

    @Override
    public SimpleSet<String> allArtists() {
        // TODO: implement this method
        return null;
    }

    @Override
    public SimpleSet<String> allAlbums() {
        // TODO: implement this method
        return null;
    }

}